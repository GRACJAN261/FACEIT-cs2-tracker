
async function fetchStats() {
  const nickname = document.getElementById("nickname").value.trim();
  const resultDiv = document.getElementById("result");
  resultDiv.style.display = "block";
  resultDiv.innerHTML = "<p>Ładowanie danych...</p>";

  if (!nickname) {
    resultDiv.innerHTML = "<p>Wpisz nick gracza.</p>";
    return;
  }

  try {
    const playerRes = await fetch(`https://open.faceit.com/data/v4/players?nickname=${nickname}`, {
      headers: { Authorization: "Bearer ce4f0948-bde9-45a0-a029-31895ec06852" }
    });
    const player = await playerRes.json();
    if (!player.player_id) throw new Error("Gracz nie istnieje");

    const matchRes = await fetch(`https://open.faceit.com/data/v4/players/${player.player_id}/history?game=cs2&limit=30`, {
      headers: { Authorization: "Bearer ce4f0948-bde9-45a0-a029-31895ec06852" }
    });
    const matchData = await matchRes.json();
    const matches = matchData.items;

    const kdArr = [];
    const adrArr = [];
    const killsArr = [];
    const labels = [];

    for (const match of matches) {
      const statRes = await fetch(`https://open.faceit.com/data/v4/matches/${match.match_id}/stats`, {
        headers: { Authorization: "Bearer ce4f0948-bde9-45a0-a029-31895ec06852" }
      });
      const stats = await statRes.json();
      const round = stats.rounds?.[0];
      if (!round) continue;

      for (const team of round.teams) {
        for (const p of team.players) {
          if (p.nickname === nickname) {
            const kills = parseInt(p.player_stats.Kills || "0");
            const deaths = parseInt(p.player_stats.Deaths || "1");
            const adr = parseFloat(p.player_stats.ADR || "0");
            kdArr.push((kills / Math.max(deaths, 1)).toFixed(2));
            adrArr.push(adr.toFixed(1));
            killsArr.push(kills);
            labels.push(new Date(match.created_at * 1000).toLocaleDateString());
          }
        }
      }
    }

    const avgADR = average(adrArr).toFixed(1);
    const avgKD = average(kdArr).toFixed(2);
    const avgKills = average(killsArr).toFixed(1);
    const level = player.games.cs2.skill_level;
    const elo = player.games.cs2.faceit_elo;

    resultDiv.innerHTML = \`
      <div class="header">
        <img src="https://cdn.faceit.com/core/faceit_level_\${level}.svg" class="level-icon">
        <h2>\${player.nickname}</h2>
        <p class="elo">ELO: \${elo} | Level \${level}</p>
      </div>
      <div class="stats-row">
        <div class="circle">ADR<br><span>\${avgADR}</span></div>
        <div class="circle">K/D<br><span>\${avgKD}</span></div>
        <div class="circle">AVG<br><span>\${avgKills}</span></div>
      </div>
      <canvas id="chart" height="100"></canvas>
    \`;

    new Chart(document.getElementById("chart"), {
      type: "line",
      data: {
        labels: labels,
        datasets: [
          { label: "K/D", data: kdArr, borderColor: "#ffa726", fill: false },
          { label: "ADR", data: adrArr, borderColor: "#66bb6a", fill: false }
        ]
      }
    });
  } catch (err) {
    resultDiv.innerHTML = "<p>Nie znaleziono gracza lub wystąpił błąd.</p>";
  }
}

function average(arr) {
  const nums = arr.map(Number);
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}
