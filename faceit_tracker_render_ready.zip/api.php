
<?php
function faceitGET($url) {
    $apiKey = "ce4f0948-bde9-45a0-a029-31895ec06852";
    $opts = ["http" => ["header" => "Authorization: Bearer $apiKey"]];
    $ctx = stream_context_create($opts);
    return json_decode(file_get_contents($url, false, $ctx), true);
}

function extractNick($input) {
    if (strpos($input, "faceit.com") !== false) {
        return basename(parse_url($input, PHP_URL_PATH));
    }
    return $input;
}
?>
