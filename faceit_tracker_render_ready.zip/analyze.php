
<?php
include 'api.php';

$input = $_POST['player'];
$nick = extractNick($input);

$playerData = faceitGET("https://open.faceit.com/data/v4/players?nickname=$nick");

if (!$playerData || !isset($playerData['player_id'])) {
    die("Nie znaleziono gracza.");
}

$playerId = $playerData['player_id'];
$elo = $playerData['games']['cs2']['faceit_elo'];
$level = $playerData['games']['cs2']['skill_level'];
$avatar = $playerData['avatar'];

$matches = faceitGET("https://open.faceit.com/data/v4/players/$playerId/history?game=cs2&limit=30")['items'];

$kd = [];
$adr = [];
$kills = [];
$dates = [];
$mapStats = [];

foreach ($matches as $match) {
    $matchId = $match['match_id'];
    $matchDetails = faceitGET("https://open.faceit.com/data/v4/matches/$matchId/stats");

    if (!isset($matchDetails['rounds'][0]['teams'])) continue;

    foreach ($matchDetails['rounds'][0]['teams'] as $team) {
        foreach ($team['players'] as $player) {
            if ($player['nickname'] === $nick) {
                $k = (int)$player['player_stats']['Kills'];
                $d = max(1, (int)$player['player_stats']['Deaths']);
                $a = (float)$player['player_stats']['ADR'];
                $map = $player['player_stats']['Map'];

                $kd[] = round($k / $d, 2);
                $adr[] = round($a, 1);
                $kills[] = $k;
                $dates[] = $match['created_at'];
                
                if (!isset($mapStats[$map])) {
                    $mapStats[$map] = ['kd' => 0, 'adr' => 0, 'kills' => 0, 'count' => 0];
                }

                $mapStats[$map]['kd'] += $k / $d;
                $mapStats[$map]['adr'] += $a;
                $mapStats[$map]['kills'] += $k;
                $mapStats[$map]['count']++;
            }
        }
    }
}

foreach ($mapStats as $map => $data) {
    $mapStats[$map]['kd_avg'] = round($data['kd'] / $data['count'], 2);
    $mapStats[$map]['adr_avg'] = round($data['adr'] / $data['count'], 1);
    $mapStats[$map]['kills_avg'] = round($data['kills'] / $data['count'], 1);
    $mapStats[$map]['map'] = $map;
}

usort($mapStats, fn($a, $b) => $b['kd_avg'] <=> $a['kd_avg']);
$max = $mapStats[0]['kd_avg'];
$min = end($mapStats)['kd_avg'];

$avgKD = round(array_sum($kd) / count($kd), 2);
$avgADR = round(array_sum($adr) / count($adr), 1);
$avgKills = round(array_sum($kills) / count($kills), 1);
?>

<!DOCTYPE html>
<html>
<head>
  <title><?= htmlspecialchars($nick) ?> – FACEIT Tracker</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <div class="container">
    <div class="header">
      <img src="https://cdn.faceit.com/core/faceit_level_<?= $level ?>.svg" class="level-icon">
      <h1><?= htmlspecialchars($nick) ?></h1>
      <p class="elo">ELO: <?= $elo ?> | Level <?= $level ?></p>
    </div>

    <div class="stats-row">
      <div class="circle">ADR<br><span><?= $avgADR ?></span></div>
      <div class="circle">K/D<br><span><?= $avgKD ?></span></div>
      <div class="circle">AVG<br><span><?= $avgKills ?></span></div>
    </div>

    <canvas id="chart" height="100"></canvas>
    <div class="legend">
      <span style="color:#ffa726;">■ K/D</span>
      <span style="color:#66bb6a;">■ ADR</span>
    </div>

    <h2>Statystyki na mapach (ostatnie 30 meczów)</h2>
    <table>
      <tr><th>Mapa</th><th>K/D</th><th>ADR</th><th>AVG Kills</th></tr>
      <?php foreach ($mapStats as $s): 
        $class = '';
        if ($s['kd_avg'] == $max) $class = 'highlight-green';
        elseif ($s['kd_avg'] == $min) $class = 'highlight-red';
      ?>
        <tr class="<?= $class ?>">
          <td><?= $s['map'] ?></td>
          <td><?= $s['kd_avg'] ?></td>
          <td><?= $s['adr_avg'] ?></td>
          <td><?= $s['kills_avg'] ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <script>
    const labels = <?= json_encode(array_map(fn($d) => date('d.m', $d), $dates)) ?>;
    const kd = <?= json_encode($kd) ?>;
    const adr = <?= json_encode($adr) ?>;

    new Chart(document.getElementById("chart"), {
      type: "line",
      data: {
        labels: labels,
        datasets: [
          { label: "K/D", data: kd, borderColor: "#ffa726", fill: false },
          { label: "ADR", data: adr, borderColor: "#66bb6a", fill: false }
        ]
      }
    });
  </script>
</body>
</html>
